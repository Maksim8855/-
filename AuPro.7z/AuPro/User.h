#ifndef USER_H
#define USER_H

#include <string>
#include <iostream>

class User {
protected:
    std::string username;

public:
    User(std::string name);
    virtual void displayInfo() const;
    std::string getUsername() const;
    virtual ~User ();
};

#endif
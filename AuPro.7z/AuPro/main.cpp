#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include "Auction.h"
#include "Buyer.h"

std::string generateRandomUsername() {
    static const std::string characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    std::string username;
    for (int i = 0; i < 5; ++i) {
        username += characters[rand() % characters.size()];
    }
    return username;
}

int main() {
    srand(static_cast<unsigned int>(time(0)));
    Auction auction;
    std::vector<std::unique_ptr<Buyer>> buyers;

    while (true) {
        std::cout << "\nМеню:\n";
        std::cout << "1. Создать аккаунт\n";
        std::cout << "2. Добавить товар\n";
        std::cout << "3. Просмотреть товары\n";
        std::cout << "4. Сделать ставку на товар\n";
        std::cout << "5. Купить товар\n";
        std::cout << "6. Выход\n";
        std::cout << "Выберите действие: ";

        int choice;
        std::cin >> choice;

        if (choice == 1) {
            std::string username;
            std::cout << "Введите имя покупателя: ";
            std::cin >> username;
            buyers.push_back(std::make_unique<Buyer>(username));
            std::cout << "Аккаунт создан!" << std::endl;

        } else if (choice == 2) {
            std::string itemName;
            double itemPrice;
            std::cout << "Введите название товара: ";
            std::cin >> itemName;
            std::cout << "Введите начальную цену товара: ";
            std::cin >> itemPrice;

            auction.addItem(std::make_unique<Item>(itemName, itemPrice, nullptr));
            std::cout << "Товар добавлен!" << std::endl;

        } else if (choice == 3) {
            auction.displayItems();

        } else if (choice == 4) {
            std::string itemName;
            double bidPrice;
            std::cout << "Введите название товара для ставки: ";
            std::cin >> itemName;
            std::cout << "Введите вашу ставку: ";
            std::cin >> bidPrice;

            if (!buyers.empty()) {
                int randomIndex = rand() % buyers.size();
                auction.bidItem(itemName, bidPrice, buyers[randomIndex].get());
            } else {
                std::cout << "Нет доступных покупателей для ставок." << std::endl;
            }

        } else if (choice == 5) {
            std::string itemName;
            std::cout << "Введите название товара для покупки: ";
            std::cin >> itemName;

            if (!buyers.empty()) {
                auction.buyItem(itemName, buyers.back().get());
            } else {
                std::cout << "Нет доступных покупателей для покупки." << std::endl;
            }

        } else if (choice == 6) {
            std::cout << "Выход из программы." << std::endl;
            break;

        } else {
            std::cout << "Неверный выбор. Попробуйте снова." << std::endl;
        }
    }

    return 0;
}

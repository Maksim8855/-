#include "Auction.h"

void Auction::addItem(std::unique_ptr<Item> item) {
    items.push_back(std::move(item));
}

void Auction::displayItems() const {
    if (items.empty()) {
        std::cout << "Нет доступных товаров." << std::endl;
        return;
    }
    for (const auto& item : items) {
        item->displayInfo();
    }
}

void Auction::buyItem(const std::string& itemName, Buyer* buyer) {
    for (auto it = items.begin(); it != items.end(); ++it) {
        if ((*it)->getName() == itemName) {
            std::cout << "Покупатель " << buyer->getUsername() << " купил " << itemName
                << " за " << (*it)->getPrice() << std::endl;
            items.erase(it);
            return;
        }
    }
    std::cout << "Товар " << itemName << " не найден." << std::endl;
}

void Auction::bidItem(const std::string& itemName, double bidPrice, Buyer* buyer) {
    for (auto& item : items) {
        if (item->getName() == itemName) {
            if (bidPrice > item->getPrice()) {
                item->setPrice(bidPrice);
                std::cout << "Покупатель " << buyer->getUsername() << " повысил цену на " << itemName
                    << " до " << bidPrice << std::endl;
                return;
            } else {
                std::cout << "Ставка слишком низкая. Текущая цена: " << item->getPrice() << std::endl;
                return;
            }
        }
    }
    std::cout << "Товар " << itemName << " не найден." << std::endl;
}

#ifndef AUCTION_H
#define AUCTION_H

#include <vector>
#include <memory>
#include "Item.h"
#include "Buyer.h"

class Auction {
private:
    std::vector<std::unique_ptr<Item>> items;

public:
    void addItem(std::unique_ptr<Item> item);
    void displayItems() const;
    void buyItem(const std::string& itemName, Buyer* buyer);
    void bidItem(const std::string& itemName, double bidPrice, Buyer* buyer);
};

#endif

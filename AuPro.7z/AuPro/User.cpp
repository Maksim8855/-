#include "User.h"

User ::User (std::string name) : username(name) {}

void User::displayInfo() const {
    std::cout << "Пользователь: " << username << std::endl;
}

std::string User::getUsername() const {
    return username;
}

User ::~User () = default;

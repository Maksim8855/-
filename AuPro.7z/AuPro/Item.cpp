#include "Item.h"

Item::Item(std::string itemName, double itemPrice, std::unique_ptr<Seller> itemOwner)
    : name(itemName), price(itemPrice), owner(std::move(itemOwner)) {}

std::string Item::getName() const {
    return name;
}

double Item::getPrice() const {
    return price;
}

void Item::setPrice(double newPrice) {
    price = newPrice;
}

void Item::displayInfo() const {
    std::cout << "Товар: " << name << ", Цена: " << price << std::endl;
}

Seller* Item::getOwner() const {
    return owner.get();
}

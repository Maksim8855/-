#ifndef ITEM_H
#define ITEM_H

#include <string>
#include <memory>
#include <iostream>
#include "Seller.h"

class Item {
private:
    std::string name;
    double price;
    std::unique_ptr<Seller> owner;

public:
    Item(std::string itemName, double itemPrice, std::unique_ptr<Seller> itemOwner);
    std::string getName() const;
    double getPrice() const;
    void setPrice(double newPrice);
    void displayInfo() const;
    Seller* getOwner() const;
};

#endif

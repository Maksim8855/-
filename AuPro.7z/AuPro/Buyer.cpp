#include "Buyer.h"

Buyer::Buyer(std::string name) : User(name) {}

void Buyer::displayInfo() const {
    std::cout << "Покупатель: " << username << std::endl;
}

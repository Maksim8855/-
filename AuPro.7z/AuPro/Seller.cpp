#include "Seller.h"

Seller::Seller(std::string name) : User(name) {}

void Seller::displayInfo() const {
    std::cout << "Продавец: " << username << std::endl;
}

#ifndef SELLER_H
#define SELLER_H

#include "User.h"

class Seller : public User {
public:
    Seller(std::string name);
    void displayInfo() const override;
};

#endif
